'use strict';

// Leaflet: Kartan näyttö
document.addEventListener('DOMContentLoaded', () => {
    const map = L.map('map').setView([60, 24], 6); // Suomen keskikohta, zoom 6
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
});

// Lootboxin avaus
async function openLootbox() {
    const gameId = document.getElementById('lootbox-game-id').value;
    const lootboxType = document.getElementById('lootbox-type').value;

    if (!gameId) {
        alert('Syötä pelin ID avataksesi lootboxin.');
        return;
    }

    try {
        const response = await fetch(`http://127.0.0.1:5000/api/lootbox?gameId=${gameId}&type=${lootboxType}`);
        const result = await response.json();

        if (response.ok) {
            alert(`Sait lootboxista: ${result.reward}`);
        } else {
            alert(`Virhe: ${result.error}`);
        }
    } catch (error) {
        alert('Virhe lootboxin avauksessa. Tarkista palvelimen yhteys.');
    }
}
